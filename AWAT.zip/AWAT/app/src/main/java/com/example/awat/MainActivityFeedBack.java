package com.example.awat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.net.MalformedURLException;
import java.net.URL;

public class MainActivityFeedBack extends AppCompatActivity {
    WebView wb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_feed_back);
        wb=(WebView) findViewById(R.id.webViewFeed);
        wb.getSettings().setJavaScriptEnabled(true);
        wb.setWebViewClient(new WebViewClient());
        try {
            wb.loadUrl(String.valueOf(new URL("https://fz4lgmgb9qt.typeform.com/to/gtjLsdvG")));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
}